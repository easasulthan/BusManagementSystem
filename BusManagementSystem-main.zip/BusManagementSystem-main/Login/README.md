# Slide Sign In/Sign Up form

A Pen created on CodePen.io. Original URL: [https://codepen.io/Navin-Morajkar/pen/mdKXMJP](https://codepen.io/Navin-Morajkar/pen/mdKXMJP).

Hi!

The other day I was looking for something easy to do and found a tutorial on how to do this form here: https://www.florin-pop.com/blog/2019/03/double-slider-sign-in-up-form/

But as you can see, I've decided to change the result a little.

Thanks!